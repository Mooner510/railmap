# railmap project documentation bundle

Generated: 2026-06-23

This bundle contains the current Railmap project documentation and planning artifacts prepared for initial project setup and implementation handoff.

## Included documents

```text
README_BUNDLE.md
docs/data-sources/DATA_SOURCE_REGISTRY.md
docs/data-sources/DATA_SOURCE_KRIC.md
docs/data-sources/DATA_SOURCE_KORAIL_RUN.md
docs/data-sources/DATA_SOURCE_OSM.md
docs/data-sources/DATA_SOURCE_TAGO_TRAIN.md
docs/collector/RAW_SNAPSHOT_POLICY.md
docs/agent/AGENT_RULES.md
docs/agent/COLLECTOR_CONTRACT.md
docs/agent/CURRENT_TASK.md
docs/planning/PROJECT_OVERVIEW.md
docs/planning/PROJECT_SETUP_TURBO.md
docs/planning/IMPLEMENTATION_ROADMAP.md
data/manual/kric-subway-route-info-line-map.csv
```

## Current decisions reflected

- KRIC `subwayRouteInfo` is `verified-sample + route allowlist provided`.
- KRIC `mreaWideCd` value set is complete: `01` 수도권, `02` 부산, `03` 대구, `04` 광주, `05` 대전.
- KRIC route collection uses `data/manual/kric-subway-route-info-line-map.csv` rather than blind brute-force.
- KRIC full allowlist API verification is deferred to collector implementation.
- KORAIL Run API rows are grouped by `run_ymd + trn_no` and ordered by numeric `trn_run_sn`.
- Missing/null KORAIL arrival/departure times must be preserved, not inferred.
- KORAIL `codes2` is not relied on because probes returned empty.
- TAGO Train remains blocked by access and is deferred.
- OSM is geometry/context only, not a timetable source.
- Broad API probing during documentation is avoided unless necessary to resolve a source ambiguity.

## Durability note

This ZIP is a transfer artifact. The durable source of truth should be the user's repository under `docs/` and `data/manual/`.
