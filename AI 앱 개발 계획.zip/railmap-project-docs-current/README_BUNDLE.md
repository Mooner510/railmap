# Railmap Project Documentation Bundle

Generated: 2026-06-23

This ZIP contains the current documentation and planning artifacts needed to start the Railmap project.

## Included repository paths

```text
docs/data-sources/DATA_SOURCE_REGISTRY.md
docs/data-sources/DATA_SOURCE_KRIC.md
docs/data-sources/DATA_SOURCE_KORAIL_RUN.md
docs/data-sources/DATA_SOURCE_OSM.md
docs/data-sources/DATA_SOURCE_TAGO_TRAIN.md
docs/collector/RAW_SNAPSHOT_POLICY.md
docs/agent/AGENT_RULES.md
docs/agent/COLLECTOR_CONTRACT.md
docs/agent/CURRENT_TASK.md
docs/planning/PROJECT_OVERVIEW.md
docs/planning/PROJECT_SETUP_TURBO.md
docs/planning/IMPLEMENTATION_ROADMAP.md
data/manual/kric-subway-route-info-line-map.csv
MANIFEST.md
```

## Use

Copy these files into the Railmap repository at the same paths.

The durable source of truth should be the user's repository, not this ZIP artifact.
