# Railmap Project Overview

Status: planning / source-documentation phase  
Audience: implementation agents and project maintainers

## 1. Project purpose

Railmap is a data-first railway and urban rail map/routing project for Korea.

The project must build its map, station, route, and timetable data from documented public/source datasets rather than fabricated sample data. Static timetable routing must use actual timetable rows only. Travel time must not be inferred from geometry, speed, distance, or visual line layout.

## 2. Current phase

The current phase is not full application implementation.

Current phase goals:

- document source datasets;
- preserve raw-source rules;
- define collector boundaries;
- define implementation-agent rules;
- prepare a small monorepo structure;
- defer broad API verification to collector implementation when appropriate.

Do not build a full public app before the data-source and collector rules are stable.

## 3. Recommended project shape

Use a TypeScript monorepo with pnpm workspace and Turborepo as a task runner/cache layer.

Recommended top-level structure:

```text
railmap/
  apps/
    web/
    local-editor/

  packages/
    collector/
    data-builder/
    schemas/
    routing/
    map-style/
    shared/

  docs/
    data-sources/
    collector/
    agent/
    decisions/
    planning/

  data/
    raw/
    probes/
    collected/
    generated/
    manual/

  scripts/
    probe/
    setup/
```

## 4. Package responsibilities

```text
packages/schemas
- raw-source schemas
- normalized schemas
- diagnostics schemas
- validation helpers

packages/collector
- source collectors
- raw response preservation
- diagnostics generation
- no inferred corrections

packages/data-builder
- raw to normalized transformation
- station/line/run graph generation
- conflict and missing-data diagnostics

packages/routing
- static timetable routing
- no geometry/speed inferred time

packages/map-style
- line/station styling
- display override application

packages/shared
- shared utilities and constants

apps/local-editor
- local-only review and manual correction UI
- not a public production app

apps/web
- public map/search/routing UI, built later
```

## 5. Primary source roles

### KRIC

Urban rail route/station code and route sequence source.

Current status:

```text
subwayRouteInfo: verified-sample + route allowlist provided
KRIC code workbook: verified-code-reference
Bulk API verification: deferred to collector implementation
```

Important rule:

```text
Do not use lnCd alone as a unique key.
Use (mreaWideCd, lnCd) and line/operator context.
```

### KORAIL Run API

Intercity/conventional rail station-stop timetable source.

Current status:

```text
travelerTrainRunInfo2: usable station-stop timetable source
travelerTrainRunPlan2: train-level plan/cross-check source
codes2: observed empty; do not rely on it
```

Important rule:

```text
Group station-stop rows by run_ymd + trn_no.
Sort stops by numeric trn_run_sn.
Do not infer missing arrival/departure times.
```

### OSM

Geometry and context source only.

Current status:

```text
Geofabrik South Korea PBF: primary OSM source
OSM Korea non-military PBF: fallback source
```

Important rule:

```text
OSM must not be used as a timetable source.
```

### TAGO Train

Secondary/cross-check source only, currently blocked by access.

Current status:

```text
blocked-by-access
Do not implement collector until access is verified.
```

## 6. Manual data

Current required manual data:

```text
data/manual/kric-subway-route-info-line-map.csv
```

This file defines the KRIC subway route allowlist for `subwayRouteInfo` collection:

```text
lnCd,노선명,mreaWideCd
```

Manual files are tracked by git. Raw/probe/generated files are not.

## 7. Design constraints

- Do not use fake or sample transit data.
- Do not infer static timetable times.
- Do not automatically translate missing station/line names.
- Preserve raw source responses before normalization.
- Keep failures as diagnostics, not silent drops.
- Do not make broad API probes during documentation unless needed to resolve a source ambiguity.
- Full allowlist verification belongs to collector implementation, not planning.

## 8. Durable source of truth

The durable source of truth is the user's repository under `docs/` and `data/manual/`.

ChatGPT-generated ZIP files are transfer artifacts, not a permanent repository.
