# Railmap Project Setup - macOS zsh + pnpm + Turborepo

Status: setup guide  
Target shell: macOS zsh

## 1. Recommended starter

Use the default `create-turbo` starter.

Do not start from a frontend-specific starter such as Tailwind/design-system/Prisma examples. This project is data-source and collector first; frontend apps come later.

Recommended choices:

```text
Starter: default create-turbo
Package manager: pnpm
Remote cache: skip / no
```

## 2. Prerequisite check

```zsh
brew --version
node -v
pnpm -v
```

If Node is missing:

```zsh
brew install node
```

If pnpm is missing:

```zsh
npm install -g pnpm
```

Verify:

```zsh
node -v
pnpm -v
```

## 3. Create the project

```zsh
mkdir -p ~/projects
cd ~/projects
pnpm dlx create-turbo@latest railmap
```

When prompted:

```text
Package manager: pnpm
Remote cache / Vercel login: No / Skip
```

Move into the project:

```zsh
cd ~/projects/railmap
```

## 4. Replace starter examples with Railmap structure

```zsh
rm -rf apps/docs packages/ui packages/eslint-config packages/typescript-config && mkdir -p   apps/web   apps/local-editor   packages/collector   packages/data-builder   packages/schemas   packages/routing   packages/map-style   packages/shared   docs/data-sources   docs/collector   docs/agent   docs/decisions   docs/planning   data/raw   data/probes   data/collected   data/generated   data/manual   scripts/probe   scripts/setup && touch data/manual/.gitkeep
```

## 5. `.gitignore`

Create `.gitignore` with:

```text
node_modules/
dist/
build/
.next/
.turbo/
.cache/

.env
.env.*
!.env.example

data/raw/
data/probes/
data/collected/
data/generated/
resource/

*.log
.DS_Store
```

## 6. `pnpm-workspace.yaml`

```yaml
packages:
  - "apps/*"
  - "packages/*"
```

## 7. `turbo.json`

```json
{
  "$schema": "https://turbo.build/schema.json",
  "tasks": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": ["dist/**", ".next/**"]
    },
    "check": {
      "dependsOn": ["^check"]
    },
    "typecheck": {
      "dependsOn": ["^typecheck"]
    },
    "lint": {
      "dependsOn": ["^lint"]
    },
    "test": {
      "dependsOn": ["^test"]
    },
    "clean": {
      "cache": false
    }
  }
}
```

## 8. Root package scripts

Root `package.json` should expose these scripts:

```json
{
  "scripts": {
    "build": "turbo build",
    "check": "turbo check",
    "typecheck": "turbo typecheck",
    "lint": "turbo lint",
    "test": "turbo test",
    "clean": "turbo clean && rm -rf node_modules .turbo"
  }
}
```

## 9. TypeScript base config

`tsconfig.base.json`:

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["ES2022"],
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "exactOptionalPropertyTypes": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true
  }
}
```

## 10. Install and check

```zsh
pnpm install
pnpm check
```

If `pnpm check` fails because of leftover starter package references, fix the package references rather than changing the source-documentation rules.

## 11. First implementation target

Do not start with `apps/web`.

Recommended first implementation target:

```text
KRIC subwayRouteInfo collector skeleton
```

It should read:

```text
data/manual/kric-subway-route-info-line-map.csv
```

and preserve raw responses and diagnostics.
