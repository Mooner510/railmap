# Railmap Implementation Roadmap

Status: implementation planning  
Scope: data-first railway/metro project

## 1. Roadmap principle

Implement in small source-grounded steps.

Do not let implementation agents redesign source strategy or browse independently. They must follow `docs/` and `data/manual/`.

## 2. Phase 0 - Documentation baseline

Current state: mostly complete.

Artifacts:

```text
docs/data-sources/DATA_SOURCE_REGISTRY.md
docs/data-sources/DATA_SOURCE_KRIC.md
docs/data-sources/DATA_SOURCE_KORAIL_RUN.md
docs/data-sources/DATA_SOURCE_OSM.md
docs/data-sources/DATA_SOURCE_TAGO_TRAIN.md
docs/collector/RAW_SNAPSHOT_POLICY.md
docs/agent/AGENT_RULES.md
docs/agent/COLLECTOR_CONTRACT.md
docs/agent/CURRENT_TASK.md
docs/planning/PROJECT_OVERVIEW.md
docs/planning/PROJECT_SETUP_TURBO.md
docs/planning/IMPLEMENTATION_ROADMAP.md
data/manual/kric-subway-route-info-line-map.csv
```

## 3. Phase 1 - Repository skeleton

Goal: establish the monorepo and empty package boundaries.

Tasks:

```text
1. Create pnpm + Turborepo monorepo.
2. Create apps and packages directories.
3. Add docs and manual data.
4. Add .gitignore raw/probe/generated rules.
5. Add root TypeScript config.
6. Do not implement full apps yet.
```

Exit criteria:

```text
pnpm install succeeds
pnpm check does not fail due to missing workspace definitions
project structure matches docs/planning/PROJECT_SETUP_TURBO.md
```

## 4. Phase 2 - Schema foundations

Goal: define source and diagnostics schemas before broad collectors.

Initial packages:

```text
packages/schemas
packages/shared
```

Schemas to define first:

```text
KRIC subwayRouteInfo raw response
KRIC route allowlist row
KORAIL travelerTrainRunInfo2 raw item
KORAIL travelerTrainRunPlan2 raw item
Source request metadata
Collector diagnostic event
Raw snapshot manifest
```

Rules:

```text
Raw schemas should preserve source field names.
Normalized schemas may use project field names.
Do not discard unknown fields from raw preservation.
```

## 5. Phase 3 - KRIC subwayRouteInfo collector

Goal: first small collector implementation.

Input:

```text
data/manual/kric-subway-route-info-line-map.csv
```

Behavior:

```text
For each allowlist row:
- call subwayRouteInfo with mreaWideCd + lnCd
- preserve raw response
- write request metadata with serviceKey redacted
- write per-route diagnostics
- do not delete configured routes on failure
```

Do not:

```text
- brute-force arbitrary lnCd values
- infer missing route results
- treat lnCd as globally unique
- run broad exploratory API probes outside configured allowlist
```

Exit criteria:

```text
Raw responses saved under data/raw/<acquired-date>/kric/subway-route-info/
Diagnostics saved under data/collected/<acquired-date>/kric/ or equivalent documented path
No service key written to disk
```

## 6. Phase 4 - KORAIL Run collector

Goal: collect and preserve intercity/conventional rail station-stop timetable data.

Primary endpoint:

```text
travelerTrainRunInfo2
```

Secondary/cross-check endpoint:

```text
travelerTrainRunPlan2
```

Rules:

```text
Group train stop rows by run_ymd + trn_no.
Sort stops by numeric trn_run_sn.
Preserve trn_no as string.
Preserve null arrival/departure values.
Do not infer missing times.
Do not rely on codes2 until it returns non-empty verified data.
Do not trust API-side date filtering until implementation verifies it.
Filter locally by response run_ymd.
```

Exit criteria:

```text
Raw paginated responses are preserved.
Pagination metadata is recorded.
Local run_ymd filtering is testable.
A single train run can be reconstructed from station-stop rows.
```

## 7. Phase 5 - OSM geometry ingestion

Goal: use OSM for geometry/context only.

Primary source:

```text
Geofabrik South Korea PBF
```

Fallback source:

```text
OSM Korea non-military PBF
```

Rules:

```text
Exclude inactive/future/deprecated railway states from normalized active data.
Keep excluded raw/probe evidence.
Do not use OSM to infer timetable travel time.
```

Exit criteria:

```text
Active rail geometry candidates are extracted.
Excluded construction/proposed/disused/abandoned/razed objects are diagnosed.
Station/route relation candidates are available for later matching.
```

## 8. Phase 6 - Data builder

Goal: transform raw source snapshots into normalized project data.

Initial outputs:

```text
normalized operators
normalized lines
normalized stations
route station sequences
train runs
station-stop timetable rows
diagnostics
```

Rules:

```text
Normalization must be reproducible from raw snapshots and manual files.
Conflicts must become diagnostics.
Manual overrides must be explicit files under data/manual/.
```

## 9. Phase 7 - Local editor

Goal: local-only review/correction UI.

Use it for:

```text
station merge review
line display overrides
transfer overrides
construction/planned line metadata
conflict resolution
```

Do not expose it as a public user-facing app.

## 10. Phase 8 - Public web app

Goal: map/search/static timetable routing frontend.

Start only after:

```text
collector outputs are stable
normalized schema is stable
routing rules are validated
manual override workflow exists
```

## 11. Current next task recommendation

Recommended next implementation task:

```text
Create repository skeleton and add current docs/data/manual files.
```

Recommended next code task after skeleton:

```text
Implement packages/schemas basics and KRIC subwayRouteInfo collector skeleton.
```
